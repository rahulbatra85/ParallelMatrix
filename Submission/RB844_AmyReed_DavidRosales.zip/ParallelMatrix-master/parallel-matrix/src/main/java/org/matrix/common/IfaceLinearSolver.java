package org.matrix.common;

public interface IfaceLinearSolver {
	public Matrix linearSolver(Matrix A, Matrix B);
}
