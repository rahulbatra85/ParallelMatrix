package org.matrix.common;

public interface IfaceAdd {
	public Matrix add(Matrix A, Matrix B);
}
