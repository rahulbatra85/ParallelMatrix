package org.matrix.common;

public interface IfaceInverse {
	public Matrix inverse(Matrix A);
}
