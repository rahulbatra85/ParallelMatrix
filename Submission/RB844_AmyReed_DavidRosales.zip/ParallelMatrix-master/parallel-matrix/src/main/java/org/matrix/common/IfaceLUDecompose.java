package org.matrix.common;

public interface IfaceLUDecompose {
	public Matrix[] LUDecompose(Matrix A);
}
