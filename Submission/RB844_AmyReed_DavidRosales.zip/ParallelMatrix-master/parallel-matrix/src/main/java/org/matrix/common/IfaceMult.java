package org.matrix.common;

public interface IfaceMult {
	public Matrix multiply(Matrix A, Matrix B);
}
