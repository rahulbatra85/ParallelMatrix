package org.matrix.seq;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestMatrixAdd {
	
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testAdd() {
		MatrixSeq m1;
		MatrixSeq m2;
		MatrixSeq m3;
		
		m1 = new MatrixSeq(4,4,false,10);
		m2 = new MatrixSeq(4,4,false,5);
			
		//fail("Matrix add returned false");

		
	}
	

}
